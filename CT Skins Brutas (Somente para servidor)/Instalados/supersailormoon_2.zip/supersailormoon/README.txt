- Super Sailor Moon II -

Skin by Natalya[AF]


To install:
Put Materials and Models in the cstrike directory.

This is meant as a server-side player skin, and will not re-skin a player model on its own.  It is to be used with a plugin like Mani Admin or Source Mod that lets you choose custom skins.


Downloads List:


//Super Sailor Moon II
models/player/natalya/supersailormoon/supersailormoon.dx80.vtx
models/player/natalya/supersailormoon/supersailormoon.dx90.vtx
models/player/natalya/supersailormoon/supersailormoon.sw.vtx
models/player/natalya/supersailormoon/supersailormoon.mdl
models/player/natalya/supersailormoon/supersailormoon.phy
models/player/natalya/supersailormoon/supersailormoon.vvd

materials/models/player/natalya/supersailormoon/bodytex.vtf
materials/models/player/natalya/supersailormoon/bodytex.vmt
materials/models/player/natalya/supersailormoon/headtex.vtf
materials/models/player/natalya/supersailormoon/headtex.vmt
materials/models/player/natalya/supersailormoon/bow.vtf
materials/models/player/natalya/supersailormoon/bow.vmt
materials/models/player/natalya/supersailormoon/wand.vtf
materials/models/player/natalya/supersailormoon/wand.vmt
materials/models/player/natalya/supersailormoon/moon_hair.vtf
materials/models/player/natalya/supersailormoon/moon_hair.vmt



Note:
The model does not have Normal Maps so it might look bad on a map that uses fullbright instead of actual lighting.

Additionally:
This is the FIXED version and will not crash Linux servers.