---------------------------------
cs:source luffy player model skin
---------------------------------

Model : PiPi
Skin : HHP227
Use tools : Autodesk 3ds max2008,3ds max7 cannonfodder's smd importer,
            Neil Jed's smd exporter,GUIStudioMDL2.2

Installation
Simply unzip the file to the directory:
Valve\Steam\SteamApps\(YOUR ACCOUNT NAME)\counter-strike source\cstrike